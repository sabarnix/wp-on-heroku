<?php
#gt3_delete_theme_option("theme_version");

/*$theme_temp_version = gt3_get_theme_option("theme_version");

if ((int)$theme_temp_version < 2) {
    gt3_update_theme_option("theme_version", 2);
}*/
?>